module DepartmentsHelper
end
